import jason.environment.grid.GridWorldModel;
import jason.environment.grid.Location;

public class DemoModel{


    private int count = 0;

    public DemoModel() {

    }

    int inc() {
        this.count++;
        return this.count;
    }


    int getCount(){
       return this.count; 
    }   
  
}
