../scripts/asciidoc-docker faq.adoc
scp faq.html  $USERSF,jason@web.sf.net:/home/groups/j/ja/jason/htdocs/doc
