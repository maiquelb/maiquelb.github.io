package env;

public class PlanetCell {

    public PlanetCell() {

    }

}
