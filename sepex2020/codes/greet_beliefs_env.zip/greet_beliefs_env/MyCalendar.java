// Environment code for project greet_beliefs_env.mas2j

import jason.asSyntax.*;
import jason.environment.*;
import java.util.logging.*;

import java.time.LocalDate;
import java.time.LocalTime;

import jason.asSyntax.parser.ParseException;

public class MyCalendar extends Environment {

    private Logger logger = Logger.getLogger("greet_beliefs_env.mas2j."+MyCalendar.class.getName());

    /** Called before the MAS execution with the args informed in .mas2j */
    @Override
    public void init(String[] args) {
        super.init(args);
		try {
        addPercept(ASSyntax.parseLiteral("percept(demo)"));
		LocalTime now = LocalTime.now();
		addPercept(ASSyntax.parseLiteral("current_hour("+ now.getHour() +")"));
		addPercept(ASSyntax.parseLiteral("current_minute("+ now.getMinute() +")"));
		addPercept(ASSyntax.parseLiteral("current_second("+ now.getSecond() +")"));
		
		LocalDate today = LocalDate.now();
		addPercept(ASSyntax.parseLiteral("current_day("+ today.getDayOfWeek().toString().toLowerCase() +")"));
		addPercept(ASSyntax.parseLiteral("current_month_day("+ today.getDayOfMonth() +")"));
		addPercept(ASSyntax.parseLiteral("current_month("+ today.getMonth().toString().toLowerCase() +")"));
		addPercept(ASSyntax.parseLiteral("current_year("+ today.getYear() +")"));
		} catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean executeAction(String agName, Structure action) {
        logger.info("executing: "+action+", but not implemented!");
        if (true) { // you may improve this condition
             informAgsEnvironmentChanged();
        }
        return true; // the action was executed with success
    }

    /** Called before the end of MAS execution */
    @Override
    public void stop() {
        super.stop();
    }
}

