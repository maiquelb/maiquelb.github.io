import java.awt.GridBagLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import java.lang.Integer;

public class DemoView{

    DemoModel dmodel;
    JLabel label = new JLabel("-");

    public DemoView(DemoModel model) {
        dmodel = model;
        
        JFrame frame = new JFrame("Demo Frame");
        JPanel panel = new JPanel();
                
        panel.setLayout(new GridBagLayout());
        panel.add(label);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setSize(500, 300);
        frame.setVisible(true);

        print_value(0);
    }


   public void print_value(int i){
      label.setText(Integer.toString(i));     
   }

}
