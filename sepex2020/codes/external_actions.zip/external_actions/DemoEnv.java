import jason.asSyntax.*;
import jason.environment.Environment;
import jason.environment.grid.Location;
import java.util.logging.Logger;

public class DemoEnv extends Environment {


    DemoModel model; // the model of the environment
    DemoView view; // the graphical representation of the environment

    @Override
    public void init(String[] args) {
        model = new DemoModel();
        view  = new DemoView(model);       
    }


    @Override
    public boolean executeAction(String ag, Structure action) {
        System.out.println("["+ag+"] doing: "+action );
        boolean result = false;
        if (action.toString().equals("inc")) { 
            model.inc();
            view.print_value(model.getCount());
            result = true;
            
        } 
        return result;
    }
}
